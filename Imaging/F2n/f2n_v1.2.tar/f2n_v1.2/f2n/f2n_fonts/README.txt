These fonts are "pilfonts" from PIL ... that do not come directly with the PIL package.
So to simplify the use of f2n.py, the 3 required fonts are included in this directory.
But know that they are plenty of other fonts available !
