Welcome !
=========
f2n.py is a tiny python module to transfrom FITS images into PNG files, built around pyfits and PIL or Pillow.
I tend to include these PNG files into html pages for fast visualization, that's why the module is called "fits to net".

Website :
http://obswww.unige.ch/~tewes/f2n_dot_py/


Installation
============

Quick :
python setup.py install

To create a source distribution :
python setup.py sdist

More info :
http://docs.python.org/distutils/
